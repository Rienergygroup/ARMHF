from datetime import datetime
from threading import Thread
from bleak import BleakScanner

import pathlib
import sys
import time
import traceback
import asyncio
import pytz

pathCorrente = pathlib.Path(__file__).parent.parent.parent.resolve().as_posix()
sys.path.append(pathCorrente)

import rienergy_logger
import scrivi_misure
import rienergy_mqtt

scriviLog = rienergy_logger.getLogger(pathLog=pathCorrente)

FORMAT_DATA_TZ = "%Y-%m-%d %H:%M:%S.%f%z"

TZ_UTC = pytz.utc

class ThreadDispositivo(Thread):
    """Thread che recupera i dati del dispositivo ogni intervallo
    """
    def __init__(self, nome:str, dispositivo:dict, mqtts:dict, infoUtente:dict):
        Thread.__init__(self, name=nome)
        self.fine = False
        self.dispositivo = dispositivo
        self.mqtts = mqtts
        self.infoUtente = infoUtente

    def run(self):
        while not self.fine:
            status = asyncio.run(self.main())
            # Se la lettura del sensore è avvenuta correttamente attendo il suo tempo di intervallo,
            #  altrimenti ritento dopo pochi secondi
            if status:
                time.sleep(int(self.dispositivo["intervallo"]))
            else:
                time.sleep(30)


    async def main(self:dict) -> bool:
        """Funzione che recupera i dati del dispositivo e li scrive nel file misure e in mqtt
    
        Args:
            self (dict): Istanza del thread contenente il JSON del dispositivo
        
        Returns:
            Boolean: Ritrona True se è stato letto tutto correttamente, False se si sono verficati errori
        """
        try:
            scriviLog.info("Recupero dati per il dispositivo %s ", self.dispositivo["descrizione"] + " " + self.dispositivo["mac"])
            devices = await BleakScanner.discover()
            for d in devices:
                if d.address.upper() == self.dispositivo["mac"].upper():
                    servizi = d.details["props"]["ServiceData"]
                    for pos in servizi:
                        # Controllo tutti i servizi in cui è possibile recuperare i dati
                        try:
                            dataLettura = datetime.utcnow().replace(tzinfo=TZ_UTC).strftime(FORMAT_DATA_TZ)
                            dati = servizi[pos].hex().upper()
                            temp = int(dati[2] + dati[3] + dati[0] + dati[1], 16) / 100

                            scriviLog.info(self.dispositivo["descrizione"] + " " + self.dispositivo["mac"] + "\n Temperatura: %s", 
                            temp)
                            try:
                                scrivi_misure.scriviMisura({
                                    "id_sensore": self.dispositivo["id"],
                                    "mac": self.dispositivo["mac"],
                                    "val_misura": temp, 
                                    "tipo_misura": "Celsius", 
                                    "nome_misura": "Temperatura", 
                                    "cod_db": self.infoUtente["cod_db"],
                                    "id_utente": self.infoUtente["id_utente"],
                                    "dt_misura": dataLettura, 
                                    "rssi": d.rssi
                                }, self.mqtts)
                            except: pass
                            return True
                        except: pass
                    break
        except Exception as e:
            scriviLog.error("Errore dispositivo %s: %s\n%s", self.dispositivo["descrizione"] + " " + self.dispositivo["mac"], e, traceback.format_exc())
            pass
        return False

def main(dispositivo:dict, mqtts:dict, infoUtente:dict) -> Thread:
    """Funzione che avvia il thread di lettura del dispositivo

    Args:
        dispositivo (dict): Dispositivo da leggere
        mqtts (dict): Lista di mqtt
        infoUtente (dict): Dati dell'utente

    Returns:
        Thread: Riferimento al thread del dispositivo
    """
    threadDispositivo = ThreadDispositivo("thread_lettura_dispositivo-" + dispositivo["id"], dispositivo, mqtts, infoUtente)
    threadDispositivo.start()
    return threadDispositivo



if __name__ == "__main__":
    main({
        "id": "1",
        "descrizione": "Sensore esterno",
        "mac": "F9:07:F4:90:09:07",
        "url_interno": "",
        "url_esterno": "",
        "user": "",
        "password": "",
        "intervallo": "20",
        "alimentazione": "",
        "tensione": "",
        "nome_pacchetto": "a",
        "nome_eseguibile": "a.py"
    }, [], {"cod_db": "100", "id_utente": "1"})