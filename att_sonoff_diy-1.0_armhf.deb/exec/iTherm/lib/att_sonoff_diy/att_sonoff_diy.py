from datetime import datetime
from requests.structures import CaseInsensitiveDict

import pathlib
import sys
import traceback
import requests

pathCorrente = pathlib.Path(__file__).parent.parent.parent.resolve().as_posix()
sys.path.append(pathCorrente)

import rienergy_logger
import scrivi_misure

scriviLog = rienergy_logger.getLogger(pathLog=pathCorrente)

class Attuatore():
    """Classe contentente i riferimenti del dispositivo per l'attuazione e recupero dati
    """
    def __init__(self, nome:str, dispositivo:dict, mqtts:list, infoUtente:dict):
        self.fine = False
        self.nome = nome
        self.dispositivo = dispositivo
        self.mqtts = mqtts
        self.infoUtente = infoUtente
        self.subscribeMqtt()

    def subscribeMqtt(self) -> None:
        """
        Funzione per sottoscriversi ai canali mqtt sui quali il dispositivo invierà i dati
        """
        # Sensore che non invia dati

    def is_alive(self) -> bool:
        """
        Funzione creata per rendere la classe sempre attiva per lo smistatore dei dispositivi

        Returns:
            bool: Sempre True
        """
        return True

    def getName(self) -> str:
        """
        Funzione che torna il nome della classe (contentente l'id del dispositivo)

        Returns:
            str: Nome passato alla classe alla creazione
        """
        return self.nome

    def getInfoDispositivo(self) -> dict:
        """
        Funzione che ritorna le info del dispositivo

        Returns:
            dict: Info del dispositivo
        """
        return self.dispositivo

    def setStatusAttuazione(self, status:dict) -> None:
        """
        Funzione che attiva disattiva il relay associato al dispositivo di attuazione

        Args:
            status (dict): Stato dell'attuazione [es. {"on": True|False}]
        """
        topicAttuatore = "smarttag/{mac}/cmnd/POWER".format(mac=self.dispositivo["mac"])
        statusRelay = "on" if status["on"] else "off"
        msgDaInviare = statusRelay

        # Gestisco il relay tramite mqtt
        for mqtt in self.mqtts:
            try:
                self.mqtts[mqtt]["rif_thread"].publish(topicAttuatore, msgDaInviare)
            except Exception as e:
                scriviLog.error("Errore invio status MQTT attuazione %s: %s\n%s",
                            self.dispositivo["descrizione"] + " " + self.dispositivo["mac"],
                            e, traceback.format_exc())

        # Attivazione del relay tramite chiamata diretta all'url (se presente)
        for posUrl in ["url_interno", "url_esterno"]:
            url = self.dispositivo[posUrl]
            if url != None and url != "":
                try:
                    url = url if "http" in url else "http://" + url
                    url = url if url[-1] == "/" else url + "/"
                    url = url + "/zeroconf/switch"

                    dataSend = """
                    { 
                        "deviceid": "", 
                        "data": {
                            "switch": "{status}" 
                        } 
                    }
                    """.format(status=statusRelay)

                    headers = CaseInsensitiveDict()
                    headers["Content-Type"] = "application/json"
                    requests.post(url, headers=headers, data=dataSend, timeout=5)
                except Exception as e:
                    scriviLog.error("Errore invio status URL attuazione %s: %s\n%s",
                             self.dispositivo["descrizione"] + " " + self.dispositivo["mac"],
                              e, traceback.format_exc())


    def gestisciLetturaAtt(self, dato:str, topic:str) -> None:
        """
        Funzione che gestisce il messaggio ricevuto dall'mqtt contentente i dati del dispositivo

        Args:
            dato (str): Dato misurato dal sensore
            topic (str): Topic sul quale è stato inviato il dato
        """
        # Sensore che non invia dati
    
def main(dispositivo:dict, mqtts:list, infoUtente:dict, **kwargs) -> Attuatore:
    """Funzione che crea a classe dell'attuatore per gestire il dispositivo

    Args:
        dispositivo (dict): Dispositivo da leggere
        mqtts (list): Lista di mqtt
        infoUtente (dict): Dati dell'utente

    Returns:
        Attuatore: Riferimento all'attuatore del dispositivo
    """
    attuatore = Attuatore("attuatore_dispositivo-" + dispositivo["id"], dispositivo, mqtts, infoUtente)
    return attuatore


if __name__ == "__main__":
    main({
        "id": "20",
        "descrizione": "Attuatore cucina",
        "mac": "shellypug-00",
        "url_interno": "",
        "url_esterno": "",
        "user": "",
        "password": "",
        "intervallo": "20",
        "alimentazione": "",
        "tensione": "",
        "nome_pacchetto": "a",
        "nome_eseguibile": "a.py"
    }, [], {"cod_db": "100", "id_utente": "1"})