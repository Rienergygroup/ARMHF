from datetime import datetime
from threading import Thread

import pathlib
import sys
import time
import traceback
import pytz

pathCorrente = pathlib.Path(__file__).parent.parent.parent.resolve().as_posix()
sys.path.append(pathCorrente)

import rienergy_logger
import scrivi_misure
import rienergy_ble_scanner

scriviLog = rienergy_logger.getLogger(pathLog=pathCorrente)

FORMAT_DATA_TZ = "%Y-%m-%d %H:%M:%S.%f%z"

TZ_UTC = pytz.utc

class ThreadDispositivo(Thread):
    """Thread che recupera i dati del dispositivo ogni intervallo
    """
    def __init__(self, nome:str, dispositivo:dict, mqtts:dict, infoUtente:dict, bleScanner:rienergy_ble_scanner.ProcessBleScanner, threadMisure:scrivi_misure.ProcessScrittuaFileMisure):
        Thread.__init__(self, name=nome)
        self.fine = False
        self.dispositivo = dispositivo
        self.mqtts = mqtts
        self.infoUtente = infoUtente
        self.bleScanner = bleScanner
        self.threadMisure = threadMisure

    def run(self):
        while not self.fine:
            status = self.main()
            # Se la lettura del sensore è avvenuta correttamente attendo il suo tempo di intervallo,
            #  altrimenti ritento dopo pochi secondi
            if status:
                time.sleep(int(self.dispositivo["intervallo"]))
            else:
                time.sleep(30)

    def main(self:dict) -> bool:
        """Funzione che recupera i dati del dispositivo e li scrive nel file misure e in mqtt
    
        Args:
            self (dict): Istanza del thread contenente il JSON del dispositivo
        
        Returns:
            Boolean: Ritrona True se è stato letto tutto correttamente, False se si sono verficati errori
        """
        try:
            scriviLog.info("Recupero dati per il dispositivo %s ", self.dispositivo["descrizione"] + " " + self.dispositivo["mac"])
            devices = []
            found = False
            try:
                if self.bleScanner is not None:
                    devices = self.bleScanner.getDispositiviTrovati()
            except Exception as e:
                scriviLog.error("Errore nel main di ble_efento.py: %s\n%s", e, traceback.format_exc())
                pass
            for d in devices:
                if d.address.upper() == self.dispositivo["mac"].upper():
                    found = True
                    servizi = d.metadata["manufacturer_data"]
                    for pos in servizi:
                        # Controllo tutti i servizi in cui è possibile recuperare i dati
                        try:
                            dataLettura = datetime.utcnow().replace(tzinfo=TZ_UTC).strftime(FORMAT_DATA_TZ)
                            dati = servizi[pos].hex().upper()
                            n = dati.find("010206")+6
                            dati = dati[n:]
                            temp = dati[0] + dati[1] + dati[2] + dati[3]
                            temp = round(int(temp, 16) / 100 - 150, 2)
                            hum = dati[4] + dati[5] + dati[6] + dati[7]
                            hum = round(int(hum, 16), 2)
                            voc = dati[10] + dati[11]
                            voc = round(int(voc, 16), 2)

                            scriviLog.info(self.dispositivo["descrizione"] + " " + self.dispositivo["mac"] + "\n Temperatura: %s   Umidita: %s   tVoc: %s", 
                            temp, hum, voc)
                            
                            misuraTemp = {
                                    "id_sensore": self.dispositivo["id"],
                                    "mac": self.dispositivo["mac"],
                                    "val_misura": temp, 
                                    "tipo_misura": "Celsius", 
                                    "nome_misura": "Temperatura", 
                                    "cod_db": self.infoUtente["cod_db"],
                                    "id_utente": self.infoUtente["id_utente"],
                                    "dt_misura": dataLettura, 
                                    "rssi": d.rssi
                                }
                            misuraHum = {
                                    "id_sensore": self.dispositivo["id"],
                                    "mac": self.dispositivo["mac"],
                                    "val_misura": hum, 
                                    "tipo_misura": "%", 
                                    "nome_misura": "Umidita", 
                                    "cod_db": self.infoUtente["cod_db"],
                                    "id_utente": self.infoUtente["id_utente"],
                                    "dt_misura": dataLettura, 
                                    "rssi": d.rssi
                                }

                            
                            misuraTvoc = {
                                    "id_sensore": self.dispositivo["id"],
                                    "mac": self.dispositivo["mac"],
                                    "val_misura": voc, 
                                    "tipo_misura": "ppm", 
                                    "nome_misura": "tVoc", 
                                    "cod_db": self.infoUtente["cod_db"],
                                    "id_utente": self.infoUtente["id_utente"],
                                    "dt_misura": dataLettura, 
                                    "rssi": d.rssi
                                }
                            
                            self.threadMisure.scriviMisure(self.mqtts, misuraTemp, misuraHum, misuraTvoc)
                            return True
                        except: pass
                    break
        except Exception as e:
            scriviLog.error("Errore dispositivo %s: %s\n%s", self.dispositivo["descrizione"] + " " + self.dispositivo["mac"], e, traceback.format_exc())
        if not found:
            scriviLog.error("Non sono riuscito a trovare %s nella lista dei dispositivi BLE", self.dispositivo["descrizione"] + " " + self.dispositivo["mac"])
        return False

def main(dispositivo:dict, mqtts:dict, infoUtente:dict, **kwargs) -> Thread:
    """Funzione che avvia il thread di lettura del dispositivo

    Args:
        dispositivo (dict): Dispositivo da leggere
        mqtts (dict): Lista di mqtt
        infoUtente (dict): Dati dell'utente

    Returns:
        Thread: Riferimento al thread del dispositivo
    """
    bleScanner = kwargs["ble_scanner"] if "ble_scanner" in kwargs else None
    threadMisure = kwargs["process_misure"] if "process_misure" in kwargs else None
    threadDispositivo = ThreadDispositivo("thread_lettura_dispositivo-" + dispositivo["id"], dispositivo, mqtts, infoUtente, bleScanner, threadMisure)
    threadDispositivo.start()
    return threadDispositivo


if __name__ == "__main__":
    main({
        "id": "1",
        "descrizione": "Sensore cucina",
        "mac": "28:2C:02:40:85:B1",
        "url_interno": "",
        "url_esterno": "",
        "user": "",
        "password": "",
        "intervallo": "20",
        "alimentazione": "",
        "tensione": "",
        "nome_pacchetto": "a",
        "nome_eseguibile": "a.py"
    }, [], {"cod_db": "100", "id_utente": "1"})