from datetime import datetime
from threading import Thread

import pathlib
import sys
import time
import traceback
import xmlrpc.client
import pytz

import chiamate_service

pathCorrente = pathlib.Path(__file__).parent.parent.parent.resolve().as_posix()
sys.path.append(pathCorrente)

import rienergy_logger
import scrivi_misure
import chiamate_comuni

scriviLog = rienergy_logger.getLogger(pathLog=pathCorrente)

FORMAT_DATA_TZ = "%Y-%m-%d %H:%M:%S.%f%z"

TZ_UTC = pytz.utc

class ThreadDispositivo(Thread):
    """Thread che recupera i dati del dispositivo ogni intervallo
    """
    def __init__(self, nome:str, dispositivo:dict, mqtts:dict, infoUtente:dict, threadMisure:scrivi_misure.ProcessScrittuaFileMisure):
        Thread.__init__(self, name=nome)
        self.fine = False
        self.dispositivo = dispositivo
        self.mqtts = mqtts
        self.infoUtente = infoUtente
        self.valorePrecedente = None
        self.threadMisure = threadMisure

    def run(self):
        while not self.fine:
            status = self.main()
            # Se la lettura del sensore è avvenuta correttamente attendo il suo tempo di intervallo,
            #  altrimenti ritento dopo pochi secondi
            if status:
                time.sleep(int(self.dispositivo["intervallo"]))
            else:
                time.sleep(30)

    def getInfoDispositivo(self) -> dict:
        """
        Funzione che ritorna le info del dispositivo

        Returns:
            dict: Info del dispositivo
        """
        return self.dispositivo

    def main(self:dict) -> bool:
        """Funzione che recupera i dati del dispositivo e li scrive nel file misure e in mqtt
    
        Args:
            self (dict): Istanza del thread contenente il JSON del dispositivo
        
        Returns:
            Boolean: Ritrona True se è stato letto tutto correttamente, False se si sono verficati errori
        """
        try:
            scriviLog.info("Recupero dati per il dispositivo %s ", self.dispositivo["descrizione"] + " " + self.dispositivo["mac"])
            user = chiamate_comuni.CCU3_USER
            password = chiamate_comuni.CCU3_PWD
            ip_centrale = chiamate_comuni.getIpCCU3()
            
            mac_xmlrpc = str(self.dispositivo["mac"])

            scriviLog.info("[CCU3] connessione a http://%s:%s@%s:2010/", user, password, ip_centrale)
            with xmlrpc.client.ServerProxy("http://"+user+":"+password+"@"+ip_centrale+":2010/") as proxy:
                proxy.init(ip_centrale, "1")           
                dati_sensore = proxy.getParamset(mac_xmlrpc + ":1", "VALUES")

                dataLettura = datetime.utcnow().replace(tzinfo=TZ_UTC).strftime(FORMAT_DATA_TZ)

                temp = dati_sensore["ACTUAL_TEMPERATURE"] if "ACTUAL_TEMPERATURE" in dati_sensore else None
                hum = dati_sensore["HUMIDITY"] if "HUMIDITY" in dati_sensore else None

                misuraTemp = None
                misuraHum = None

                if temp != None:
                    misuraTemp = {
                        "id_sensore": self.dispositivo["id"],
                        "mac": self.dispositivo["mac"],
                        "val_misura": temp, 
                        "tipo_misura": "°C", 
                        "nome_misura": "Temperatura", 
                        "cod_db": self.infoUtente["cod_db"],
                        "id_utente": self.infoUtente["id_utente"],
                        "id_centralina": self.dispositivo["fk_centralina"],
                        "dt_misura": dataLettura, 
                        "rssi": "0"
                    }
                if hum != None:
                    misuraHum = {
                        "id_sensore": self.dispositivo["id"],
                        "mac": self.dispositivo["mac"],
                        "val_misura": hum, 
                        "tipo_misura": "%", 
                        "nome_misura": "Umidita", 
                        "cod_db": self.infoUtente["cod_db"],
                        "id_utente": self.infoUtente["id_utente"],
                        "id_centralina": self.dispositivo["fk_centralina"],
                        "dt_misura": dataLettura, 
                        "rssi": "0"
                    }
                
                self.threadMisure.scriviMisure(self.mqtts, misuraTemp, misuraHum)

                
                # Update status batteria
                try:
                    dati = proxy.getParamset(mac_xmlrpc + ":0", "VALUES")
                    lowBat = dati["LOW_BAT"] if "LOW_BAT" in dati else None
                    lowBat = lowBat if lowBat != '' else None
                    if lowBat != None:
                        datiUtente = {"id_utente": self.infoUtente["id_utente"], "id_centralina": self.dispositivo["fk_centralina"], "cod_db": self.infoUtente["cod_db"]}
                        chiamate_service.updateBatteriaScarica(self.dispositivo["id"], lowBat, mqtts=self.mqtts, datiUtente=datiUtente)
                except Exception as e: scriviLog.error("Errore update batteria:%s\n %s", e, traceback.format_exc())

                return True
        except Exception as e:
            scriviLog.error("Errore dispositivo %s: %s\n%s", self.dispositivo["descrizione"] + " " + self.dispositivo["mac"], e, traceback.format_exc())
            pass
        return False
def main(dispositivo:dict, mqtts:dict, infoUtente:dict, **kwargs) -> Thread:
    """Funzione che avvia il thread di lettura del dispositivo

    Args:
        dispositivo (dict): Dispositivo da leggere
        mqtts (dict): Lista di mqtt
        infoUtente (dict): Dati dell'utente

    Returns:
        Thread: Riferimento al thread del dispositivo
    """
    threadMisure = kwargs["process_misure"] if "process_misure" in kwargs else None
    threadDispositivo = ThreadDispositivo("thread_lettura_dispositivo-" + dispositivo["id"], dispositivo, mqtts, infoUtente, threadMisure)
    threadDispositivo.start()
    return threadDispositivo