from datetime import datetime, timezone, tzinfo
import pathlib
import sys
from threading import Thread
import time
import traceback
import asyncio
import xmlrpc.client
import requests, base64, json, datetime, pytz

pathCorrente = pathlib.Path(__file__).parent.parent.parent.resolve().as_posix()
sys.path.append(pathCorrente)

import rienergy_logger
import scrivi_misure

scriviLog = rienergy_logger.getLogger(pathLog=pathCorrente)

# API per utilizzare i sensori Qingping

API_SERVER_URL = "https://apis.cleargrass.com"
AUTH_SERVER_URL = "https://oauth.cleargrass.com/oauth2/token"

def codificaBase64(val):
    message_bytes = val.encode('ascii')
    base64_bytes = base64.b64encode(message_bytes)
    base64_message = base64_bytes.decode('ascii')
    base64_message = base64_message.replace("=", "")
    return str(base64_message)

def decodificaBase64(val):
    val = val + '=' * (-len(val) % 4)
    base64_bytes = val.encode('ascii')
    message_bytes = base64.b64decode(base64_bytes)
    message = message_bytes.decode('ascii')
    return str(message)

def calcolaTimeStamp():
    data = datetime.datetime.now(pytz.utc)
    return str(int(data.timestamp() * 1000))

def dataToTimestamp(data_str):
    data = datetime.datetime.strptime(data_str, "%Y-%m-%d %H:%M:%S")
    return str(int(data.timestamp()))

def timestampToDate(timestamp):
    data = datetime.datetime.fromtimestamp(float(timestamp))
    data = data.replace(tzinfo=timezone.utc)
    return data.strftime("%Y-%m-%d %H:%M:%S")

def getToday():
    data = datetime.datetime.now()
    return data.strftime("%Y-%m-%d %H:%M:%S")

def getTodayTimestamp():
    data = datetime.datetime.now()
    return str(int(data.timestamp()))

def getPastFrom(data_str=getToday(), val=1, tipo="days"):
    data = datetime.datetime.strptime(data_str, "%Y-%m-%d %H:%M:%S")
    if tipo == "days":
        data  = data - datetime.timedelta(days=val)
    elif tipo == "hours":
        data  = data - datetime.timedelta(hours=val)
    elif tipo == "minutes":
        data  = data - datetime.timedelta(minutes=val)
    
    return str(int(data.timestamp()))


def get_new_token(client_id, client_secret):
    """
        Utilizzando client_id e client_secret 
            - non codificati
            - che l'utente conosce e genera alla pagina https://developer.qingping.co/

        Ritorno il token per effettuare le chiamate
            - Il token scade ogni 2 ore
    """
    header_request = {}
    body_request = {}

    header_request["Content-Type"] = "application/x-www-form-urlencoded"
    header_request["Authorization"] = "Basic "+codificaBase64(client_id+":"+client_secret)
    body_request["grant_type"] = 'client_credentials'
    body_request["scope"] = "device_full_access"

    response = requests.post(AUTH_SERVER_URL, data=body_request, headers=header_request)
    
    if response.status_code != 200:
        scriviLog("Errore API Qingping: %s", response.text)
        return False

    tokens = json.loads(response.text)
    return tokens['access_token']

def get_dispositivi(token):
    """
        Utilizzando token 
            - parametro di ritorno della funzione get_new_token
        
        Effettuo la chiamata per recuperare i dispositivi dell'utente
    """

    timestamp = calcolaTimeStamp()


    header_request = {}
    body_request = {}

    header_request["Authorization"] = "Bearer "+token

    url = API_SERVER_URL + "/v1/apis/devices?timestamp="+str(timestamp)
    response = requests.get(url, data=body_request, headers=header_request)
    
    if response.status_code != 200:
        scriviLog("Errore API Qingping: %s", response.text)
        return {"total": 0, "devices": []}
        
    dati = json.loads(response.text)
    return dati

def get_history(token, mac, dt_start, dt_end, limit=200, offset=0):
    """
        Utilizzando token 
            - parametro di ritorno della funzione get_new_token
        
        Effettuo la chiamata per recuperare i dispositivi dell'utente

        mac [MAC del dispositivo]
        dt_start [Data dalla quale partire a recuperare i dati]
        dt_end [Data alla quale cessa il recupero i dati]
        limit [Limite di elementi da recuperare (Default=200)]
        offset [Offset dei valori (Default=0)]
    """

    timestamp = calcolaTimeStamp()

    header_request = {}
    body_request = {}

    header_request["Authorization"] = "Bearer "+token

    url = API_SERVER_URL + "/v1/apis/devices/data?timestamp="+str(timestamp)
    url = url + "&mac="+mac
    url = url + "&end_time="+dt_end
    url = url + "&start_time="+dt_start
    url = url + "&limit="+str(limit)
    url = url + "&offset="+str(offset)
    response = requests.get(url, data=body_request, headers=header_request)
    
    if response.status_code != 200:
        scriviLog("Errore API Qingping: %s", response.text)
        return {"total": 0, "data": []}
        
    dati = json.loads(response.text)
    return dati

def modify_settings(token, mac, report_interval, collect_interval):
    """
        Utilizzando token 
        - parametro di ritorno della funzione get_new_token
        
        Effettuo la chiamata modificare i valori per inviare i date in cloud

        - mac [MAC del dispositivo]\n
        - report_interval [Report interval (second), minimum is 10 second, an integer multiple of collect_interval]\n
        - collect_interval [Data acquisition and report interval (second)]\n
        \n
        Ritrona False se non è stato possibile modificare True se è andata tutto a buon fine
    """

    timestamp = calcolaTimeStamp()

    header_request = {}
    body_request = {}

    header_request["Authorization"] = "Bearer "+token
    header_request["Content-Type"] = "application/json"

    url = API_SERVER_URL + "/v1/apis/devices/settings"

    body_request = """
        {"mac": [\"""" + str(mac) + """\"],
        "timestamp": """+str(timestamp)+""",
        "report_interval": """+str(report_interval)+""",
        "collect_interval": """+str(collect_interval)+"""}
        """

    response = requests.put(url, data=body_request, headers=header_request)

    if response.status_code != 200:
        scriviLog("Errore API Qingping: %s", response.text)
        return False
    
    return True

def unbind(token, mac):
    """
        Utilizzando token 
        - parametro di ritorno della funzione get_new_token
        
        Dissocio il dispositivi dall'utente a cui appartiene il token

        - mac [MAC del dispositivo]\n

        Ritrona False se non è stato possibile dissociarlo True se è andata tutto a buon fine
    """

    timestamp = calcolaTimeStamp()

    header_request = {}
    body_request = {}

    header_request["Authorization"] = "Bearer "+token
    header_request["Content-Type"] = "application/json"

    url = API_SERVER_URL + "/v1/apis/devices/devices"

    body_request = """
        {"mac": [\"""" + str(mac) + """\"],
        "timestamp": """+str(timestamp)+"""
        """

    response = requests.delete(url, data=body_request, headers=header_request)

    if response.status_code != 200:
        scriviLog("Errore API Qingping: %s", response.text)
        return False
    
    return True

def bind(token, device_token, product_id, timestamp):
    """
        Utilizzando token 
        - parametro di ritorno della funzione get_new_token
        
        Dissocio il dispositivi dall'utente a cui appartiene il token

        - device_token [Identificativo presente sul dispositivo da associare]\n
        - product_id [Identificativo presente nella tabella (1)]\n

        (1): 
        - [1001]	Qingping Temp & RH Monitor Pro S
        - [1101]	Qingping Temp & RH Barometer
        - [1201]	Qingping Air Monitor
        - [1203]	Qingping Air Monitor Lite
        - [1401]	Qingping Bluetooth Alarm Clock
        - [1501]	Qingping Motion & Ambient Light Sensor
        - [1502]	Qingping Door/Window Contact Sensor

        Ritrona False se non è stato possibile associarlo True se è andata tutto a buon fine
    """

    timestamp = calcolaTimeStamp()

    header_request = {}
    body_request = {}

    header_request["Authorization"] = "Bearer "+token
    header_request["Content-Type"] = "application/json"

    url = API_SERVER_URL + "/v1/apis/devices/devices"

    body_request = """
        {"device_token": \"""" + str(device_token) + """\",
        "product_id": """+str(product_id)+""",
        "timestamp": """+str(timestamp)+"""
        """

    response = requests.post(url, data=body_request, headers=header_request)

    if response.status_code != 200:
        scriviLog("Errore API Qingping: %s", response.text)
        return False
    
    return True


# Thread lettura dispositivo

class ThreadDispositivo(Thread):
    """Thread che recupera i dati del dispositivo ogni intervallo
    """
    def __init__(self, nome:str, dispositivo:dict, mqtts:dict, infoUtente:dict):
        Thread.__init__(self, name=nome)
        self.fine = False
        self.dispositivo = dispositivo
        self.mqtts = mqtts
        self.infoUtente = infoUtente

    def run(self):
        while not self.fine:
            status = asyncio.run(self.main())
            # Se la lettura del sensore è avvenuta correttamente attendo il suo tempo di intervallo,
            #  altrimenti ritento dopo pochi secondi
            if status:
                time.sleep(int(self.dispositivo["intervallo"]))
            else:
                time.sleep(30)


    async def main(self:dict) -> bool:
        """Funzione che recupera i dati del dispositivo e li scrive nel file misure e in mqtt
    
        Args:
            self (dict): Istanza del thread contenente il JSON del dispositivo
        
        Returns:
            Boolean: Ritrona True se è stato letto tutto correttamente, False se si sono verficati errori
        """
        try:
            scriviLog.info("Recupero dati per il dispositivo %s ", self.dispositivo["descrizione"] + " " + self.dispositivo["mac"])

            scriviLog.info("[API-QINGPING] connessione a %s", API_SERVER_URL)
            
            token = get_new_token(self.dispositivo["user"], self.dispositivo["password"])
            if token != False:
                dispositivi = get_dispositivi(token)
                if dispositivi["total"] > 0:
                    for dispositivo in dispositivi["devices"]:
                        if self.dispositivo["mac"].replace(":", "").upper() == dispositivo["info"]["mac"].upper():
                            dataLettura = timestampToDate(dispositivo["data"]["timestamp"]["value"])
                            temperature = str(dispositivo["data"]["temperature"]["value"])
                            humidity = str(dispositivo["data"]["humidity"]["value"])
                            tvoc = str(dispositivo["data"]["tvoc"]["value"])
                            co2 = str(dispositivo["data"]["co2"]["value"])
                            pm25 = str(dispositivo["data"]["pm25"]["value"])
                            pm10 = str(dispositivo["data"]["pm10"]["value"])

                            scriviLog.info(self.dispositivo["descrizione"] + " " + self.dispositivo["mac"] + 
                            "\nData: %s\nTemperatura: %s    Umidita: %s    tVoc: %s    CO2: %s\npm2.5: %s    pm10: %s", 
                            dataLettura, temperature, humidity, tvoc, co2, pm25, pm10)

                            try:
                                scrivi_misure.scriviMisura({
                                    "id_sensore": self.dispositivo["id"],
                                    "mac": self.dispositivo["mac"],
                                    "val_misura": temperature, 
                                    "tipo_misura": "Celsius", 
                                    "nome_misura": "Temperatura", 
                                    "cod_db": self.infoUtente["cod_db"],
                                    "id_utente": self.infoUtente["id_utente"],
                                    "dt_misura": dataLettura, 
                                    "rssi": "0"
                                }, self.mqtts)
                            except: pass
                            try:
                                scrivi_misure.scriviMisura({
                                    "id_sensore": self.dispositivo["id"],
                                    "mac": self.dispositivo["mac"],
                                    "val_misura": humidity, 
                                    "tipo_misura": "%", 
                                    "nome_misura": "Umidita", 
                                    "cod_db": self.infoUtente["cod_db"],
                                    "id_utente": self.infoUtente["id_utente"],
                                    "dt_misura": dataLettura, 
                                    "rssi": "0"
                                }, self.mqtts)
                            except: pass
                            try:
                                scrivi_misure.scriviMisura({
                                    "id_sensore": self.dispositivo["id"],
                                    "mac": self.dispositivo["mac"],
                                    "val_misura": tvoc, 
                                    "tipo_misura": "ppm", 
                                    "nome_misura": "tVoc", 
                                    "cod_db": self.infoUtente["cod_db"],
                                    "id_utente": self.infoUtente["id_utente"],
                                    "dt_misura": dataLettura, 
                                    "rssi": "0"
                                }, self.mqtts)
                            except: pass
                            try:
                                scrivi_misure.scriviMisura({
                                    "id_sensore": self.dispositivo["id"],
                                    "mac": self.dispositivo["mac"],
                                    "val_misura": co2, 
                                    "tipo_misura": "ppm", 
                                    "nome_misura": "CO2", 
                                    "cod_db": self.infoUtente["cod_db"],
                                    "id_utente": self.infoUtente["id_utente"],
                                    "dt_misura": dataLettura, 
                                    "rssi": "0"
                                }, self.mqtts)
                            except: pass
                            try:
                                scrivi_misure.scriviMisura({
                                    "id_sensore": self.dispositivo["id"],
                                    "mac": self.dispositivo["mac"],
                                    "val_misura": pm25, 
                                    "tipo_misura": "ppm", 
                                    "nome_misura": "pm2.5", 
                                    "cod_db": self.infoUtente["cod_db"],
                                    "id_utente": self.infoUtente["id_utente"],
                                    "dt_misura": dataLettura, 
                                    "rssi": "0"
                                }, self.mqtts)
                            except: pass
                            try:
                                scrivi_misure.scriviMisura({
                                    "id_sensore": self.dispositivo["id"],
                                    "mac": self.dispositivo["mac"],
                                    "val_misura": pm10, 
                                    "tipo_misura": "ppm", 
                                    "nome_misura": "pm10", 
                                    "cod_db": self.infoUtente["cod_db"],
                                    "id_utente": self.infoUtente["id_utente"],
                                    "dt_misura": dataLettura, 
                                    "rssi": "0"
                                }, self.mqtts)
                            except: pass


                            return True
            else:
                scriviLog.info("Errone nella connessione delle API")
        except Exception as e:
            scriviLog.error("Errore dispositivo %s: %s\n%s", self.dispositivo["descrizione"] + " " + self.dispositivo["mac"], e, traceback.format_exc())
            pass
        return False

def main(dispositivo:dict, mqtts:dict, infoUtente:dict, **kwargs) -> Thread:
    """Funzione che avvia il thread di lettura del dispositivo

    Args:
        dispositivo (dict): Dispositivo da leggere
        mqtts (dict): Lista di mqtt
        infoUtente (dict): Dati dell'utente

    Returns:
        Thread: Riferimento al thread del dispositivo
    """
    threadDispositivo = ThreadDispositivo("thread_lettura_dispositivo-" + dispositivo["id"], dispositivo, mqtts, infoUtente)
    threadDispositivo.start()
    return threadDispositivo


if __name__ == "__main__":
    main({
        "id": "1",
        "descrizione": "Sensore Aria",
        "mac": "58:2D:34:00:17:73",
        "url_interno": "192.168.1.12",
        "url_esterno": "192.168.1.12",
        "user": "xi-PGog7g",
        "password": "f71851a4cf3911eb9deb00163e126199",
        "intervallo": "20",
        "alimentazione": "",
        "tensione": "",
        "nome_pacchetto": "a",
        "nome_eseguibile": "a.py"
    }, [], {"cod_db": "100", "id_utente": "1"})