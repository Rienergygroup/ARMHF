from datetime import datetime
from threading import Thread

import pathlib
import sys
import time
import traceback
import xmlrpc.client
import pytz

import chiamate_service

pathCorrente = pathlib.Path(__file__).parent.parent.parent.resolve().as_posix()
sys.path.append(pathCorrente)

import rienergy_logger
import rienergy_mqtt
import scrivi_misure
import chiamate_comuni

scriviLog = rienergy_logger.getLogger(pathLog=pathCorrente)

FORMAT_DATA_TZ = "%Y-%m-%d %H:%M:%S.%f%z"

TZ_UTC = pytz.utc

class ThreadDispositivo(Thread):
    """Thread che recupera i dati del dispositivo ogni intervallo
    """
    def __init__(self, nome:str, dispositivo:dict, mqtts:dict, infoUtente:dict, threadMisure:scrivi_misure.ProcessScrittuaFileMisure, configDispositivi:dict):
        Thread.__init__(self, name=nome)
        self.fine = False
        self.dispositivo = dispositivo
        self.mqtts = mqtts
        self.infoUtente = infoUtente
        self.ip_centrale = chiamate_comuni.getIpCCU3()
        self.valorePrecedente = {"Apertura": {"valore": None, "data_misura": datetime(1989, 2, 24)}, "Sabotaggio": {"valore": None, "data_misura": datetime(1989, 2, 24)}}
        self.threadMisure = threadMisure
        self.configDispositivi = configDispositivi
        self.topicInfo = rienergy_mqtt.TOPIC_INFO.format(codDb=infoUtente["cod_db"], idUtente=infoUtente["id_utente"], idCentralina=infoUtente["id_centralina"])


    def run(self):
        while not self.fine:
            status = self.main()
            # Se la lettura del sensore è avvenuta correttamente attendo il suo tempo di intervallo,
            #  altrimenti ritento dopo pochi secondi
            msgStatus = rienergy_mqtt.TEMPLATE_MSG_STATUS_DEVICE
            msgStatus["id_dispositivo"] = self.dispositivo["id"]
            msgStatus["status"] = status
            rienergy_mqtt.inviaMessaggio(msg=msgStatus, topic=self.topicInfo, mqtts=self.mqtts, filterMqtt="com")
            
            if status:
                try:
                    if int(self.dispositivo["intervallo"]) <= 0: 
                        self.dispositivo["intervallo"] = self.configDispositivi["intervallo_letture_setpoint"]
                except:
                    self.dispositivo["intervallo"] = self.configDispositivi["intervallo_letture_setpoint"]
                tAttesa = int(self.dispositivo["intervallo"]) 
            else:
                tAttesa = self.configDispositivi["intervallo_errore"]
            time.sleep(tAttesa)

    def getInfoDispositivo(self) -> dict:
        """
        Funzione che ritorna le info del dispositivo

        Returns:
            dict: Info del dispositivo
        """
        return self.dispositivo

    def main(self:dict) -> bool:
        """Funzione che recupera i dati del dispositivo (se presenti) e li scrive nel file misure e in mqtt e controlla lo stato della valvola
    
        Args:
            self (dict): Istanza del thread contenente il JSON del dispositivo
        
        Returns:
            Boolean: Ritrona True se è stato letto tutto correttamente, False se si sono verficati errori
        """
        try:
            scriviLog.info("Recupero dati per il dispositivo %s ", self.dispositivo["descrizione"] + " " + self.dispositivo["mac"])
            user = chiamate_comuni.CCU3_USER
            password = chiamate_comuni.CCU3_PWD
            
            mac_xmlrpc = str(self.dispositivo["mac"])

            # scriviLog.info("[CCU3] connessione a http://%s:%s@%s:2010/", user, password, self.ip_centrale)
            with xmlrpc.client.ServerProxy("http://"+user+":"+password+"@"+self.ip_centrale+":2010/") as proxy:
                #  proxy.init(self.ip_centrale, "1")           
                datiSensore = proxy.getParamset(mac_xmlrpc + ":1", "VALUES")
                dati = proxy.getParamset(mac_xmlrpc + ":0", "VALUES")

                dataLettura = datetime.utcnow().replace(tzinfo=TZ_UTC).strftime(FORMAT_DATA_TZ)

                state = datiSensore["STATE"] if "STATE" in datiSensore else None
                sabotage = (1 if dati["SABOTAGE"] else 0) if "SABOTAGE" in dati else None

                misuraState = None
                misuraSabotage = None

                if state != None and (state != self.valorePrecedente["Apertura"]["valore"] or 
                                        (datetime.utcnow() - self.valorePrecedente["Apertura"]["data_misura"]).seconds >= self.configDispositivi["timeout_valori_uguali"]):
                    self.valorePrecedente["Apertura"]["valore"] = state
                    self.valorePrecedente["Apertura"]["data_misura"] = datetime.utcnow()
                    misuraState = {
                        "id_sensore": self.dispositivo["id"],
                        "mac": self.dispositivo["mac"],
                        "val_misura": state, 
                        "tipo_misura": "Chiuso/Aperto", 
                        "nome_misura": "Apertura", 
                        "cod_db": self.infoUtente["cod_db"],
                        "id_utente": self.infoUtente["id_utente"],
                        "id_centralina": self.dispositivo["fk_centralina"],
                        "dt_misura": dataLettura, 
                        "rssi": "0"
                    }

                if sabotage != None and (sabotage != self.valorePrecedente["Sabotaggio"]["valore"] or 
                                        (datetime.utcnow() - self.valorePrecedente["Sabotaggio"]["data_misura"]).seconds >= self.configDispositivi["timeout_valori_uguali"]):
                    self.valorePrecedente["Sabotaggio"]["valore"] = sabotage
                    self.valorePrecedente["Sabotaggio"]["data_misura"] = datetime.utcnow()
                    misuraSabotage = {
                        "id_sensore": self.dispositivo["id"],
                        "mac": self.dispositivo["mac"],
                        "val_misura": sabotage, 
                        "tipo_misura": "Chiuso/Aperto", 
                        "nome_misura": "Sabotaggio", 
                        "cod_db": self.infoUtente["cod_db"],
                        "id_utente": self.infoUtente["id_utente"],
                        "id_centralina": self.dispositivo["fk_centralina"],
                        "dt_misura": dataLettura, 
                        "rssi": "0"
                    }
                
                self.threadMisure.scriviMisure(self.mqtts, misuraState, misuraSabotage)
                
                # Update status batteria
                try:
                    dati = proxy.getParamset(mac_xmlrpc + ":0", "VALUES")
                    lowBat = dati["LOW_BAT"] if "LOW_BAT" in dati else None
                    lowBat = lowBat if lowBat != '' else None
                    if lowBat != None:
                        datiUtente = {"id_utente": self.infoUtente["id_utente"], "id_centralina": self.dispositivo["fk_centralina"], "cod_db": self.infoUtente["cod_db"]}
                        chiamate_service.updateBatteriaScarica(self.dispositivo["id"], lowBat, mqtts=self.mqtts, datiUtente=datiUtente)
                except Exception as e: scriviLog.error("Errore update batteria:%s\n %s", e, traceback.format_exc())

                return True
        except Exception as e:
            scriviLog.error("Errore dispositivo %s: %s\n%s", self.dispositivo["descrizione"] + " " + self.dispositivo["mac"], e, traceback.format_exc())
            self.ip_centrale = chiamate_comuni.getIpCCU3()
        return False

def main(dispositivo:dict, mqtts:dict, infoUtente:dict, **kwargs) -> Thread:
    """Funzione che avvia il thread di lettura del dispositivo

    Args:
        dispositivo (dict): Dispositivo da leggere
        mqtts (dict): Lista di mqtt
        infoUtente (dict): Dati dell'utente

    Returns:
        Thread: Riferimento al thread del dispositivo
    """
    threadMisure = kwargs["process_misure"] if "process_misure" in kwargs else None
    configDispositivi = kwargs["config_dispositivi"] if "config_dispositivi" in kwargs else {}
    threadDispositivo = ThreadDispositivo("thread_lettura_dispositivo-" + dispositivo["id"], dispositivo, mqtts, infoUtente, threadMisure, configDispositivi)
    threadDispositivo.start()
    return threadDispositivo